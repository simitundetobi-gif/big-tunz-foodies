# BIG TUNZ FOODIES

Igbinedion University campus food ordering website.

## Render settings
- Environment: Node
- Branch: main
- Root Directory: leave empty
- Build Command: npm install
- Start Command: node server.js

## Files
- index.html — website
- server.js — Paystack payment initialization + webhook server
- package.json — Node dependencies
- .env.example — environment variable names

## Important
Never put your Paystack secret key or WhatsApp access token inside index.html or commit them to GitHub. Add them as Render Environment Variables.
